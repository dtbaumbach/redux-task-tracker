import React from 'react'
import Task from './Task'

const Tasks = () => {
  return (
    <div>
        <Task />
    </div>
  )
}

export default Tasks